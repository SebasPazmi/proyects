alert("HOLA");
alert("BUENOS DIAS, TARDE O NOCHES");
alert("BIENVENIDO A MI CURRICULUM VITAE");
alert("ADVERTENCIA: ESTE CURRICULUM FORMA PARTE DE MI PROYECTO DE FIN DE CURSO");




console.log("Este es el log de mi curriculum vitae");
var minombre = "SEBASTIÁN ANDRÉS PAZMIÑO CRUZ";
var edad = 20;
var altura = 1.83;
var estudios= "DESARROLLO DE SOFTWARE";
var resid="QUITO-ECUADOR";

console.log("Mi nombre completo es: " ,minombre);
console.log("Tengo ",edad, "años");
console.log("Mido ", altura);
console.log("Estoy estudiando " ,estudios);
console.log("Vivo en ",resid);


document.getElementById('patt').innerHTML='ESTADO SENTIMENTAL: EN UNA RELACIÓN';
document.getElementById('pat1t').innerHTML='MAYOR MIEDO: AVES';
document.getElementById('pat12t').innerHTML='COMIDA FAVORITA: POLLO KFC';
document.getElementById('pat13t').innerHTML='BEBIDA FAVORITA: PEPSI';
document.getElementById('pat14t').innerHTML='¿TIENES HERMANOS?: NO';
document.getElementById('pat15t').innerHTML='VIDEOJUEGO FAVORITO: RESIDENT EVIL 4';



function jfunction1(){console.log("¡QUE OBEDIENTE XD!");}
var miboton=document.getElementById("jboton12");
miboton.addEventListener("click", jfunction1);
