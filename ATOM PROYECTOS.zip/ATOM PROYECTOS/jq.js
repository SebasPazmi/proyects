$(document).ready(function(){alert("si funciona!");});
